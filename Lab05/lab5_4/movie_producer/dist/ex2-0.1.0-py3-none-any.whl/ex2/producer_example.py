from kafka import KafkaProducer
import json
import random
import time

TOPIC = "lab05_ex4_shows"
nMec = 113626

quotes = [
    {"quote": "May the Force be with you.", "movie": {"title": "Star Wars", "year": 1977}},
    {"quote": "I'm going to make him an offer he can't refuse.", "movie": {"title": "The Godfather", "year": 1972}},
    {"quote": "You talking to me?", "movie": {"title": "Taxi Driver", "year": 1976}},
    {"quote": "I'll be back.", "movie": {"title": "The Terminator", "year": 1984}},
    {"quote": "Here's looking at you, kid.", "movie": {"title": "Casablanca", "year": 1942}},
]

def generate_quote():
    return random.choice(quotes)

def main():
    producer = KafkaProducer(
        bootstrap_servers='localhost:29092',
        value_serializer=lambda v: json.dumps(v).encode('utf-8')
    )

    print("Starting Kafka producer...")

    try:
        while True:
            quote = generate_quote()
            message = {
                "quote": quote["quote"],
                "movie": {
                    "title": quote["movie"]["title"],
                    "year": quote["movie"]["year"]
                }
            }

            # Send the quote to the Kafka topic
            producer.send(TOPIC, message)
            print(f"Produced: {message}")

            # Random sleep between 5 to 10 seconds
            time.sleep(random.uniform(5, 10))
    except KeyboardInterrupt:
        print("Stopping Kafka producer.")
    finally:
        producer.flush()
        producer.close()

if __name__ == "__main__":
    main()
