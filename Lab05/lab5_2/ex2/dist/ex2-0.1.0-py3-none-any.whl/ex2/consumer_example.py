from kafka import KafkaConsumer
import json

# Define topic
TOPIC = "lab05_113626"

def main():
    # Initialize Kafka consumer with Docker container settings
    consumer = KafkaConsumer(
        TOPIC,
        bootstrap_servers='localhost:29092',  # Use Docker's exposed Kafka port
        auto_offset_reset='earliest',
        enable_auto_commit=True,
        value_deserializer=lambda v: json.loads(v.decode('utf-8'))
    )

    # Read messages from Kafka
    last_message = None
    print("Consuming messages...")
    for message in consumer:
        print(f"Consumed: {message.value}")
        last_message = message.value

    print(f"Last Message: {last_message}")

if __name__ == "__main__":
    main()