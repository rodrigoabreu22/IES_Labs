from kafka import KafkaProducer
import json

# Define topic and nMec
TOPIC = "lab05_113626"
nMec = 99999

def generate_fibonacci_sequence(n):
    sequence = []
    a, b = 0, 1
    while a <= n:
        sequence.append(a)
        a, b = b, a + b
    return sequence

def main():
    # Initialize Kafka producer with Docker container settings
    producer = KafkaProducer(
        bootstrap_servers='localhost:29092',  # Use Docker's exposed Kafka port
        value_serializer=lambda v: json.dumps(v).encode('utf-8')
    )

    # Generate Fibonacci sequence
    sequence = generate_fibonacci_sequence(nMec)

    # Produce messages to Kafka
    for num in sequence:
        message = {'nMec': '113626', 'generatedNumber': num, 'type': 'fibonacci'}
        producer.send(TOPIC, message)
        print(f"Produced: {message}")

    producer.flush()
    producer.close()

if __name__ == "__main__":
    main()